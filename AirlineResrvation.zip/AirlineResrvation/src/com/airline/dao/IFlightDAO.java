package com.airline.dao;

import java.util.List;

import com.airline.entities.FlightInformation;

public interface IFlightDAO {
	
	
	public List<FlightInformation> viewAllFlights();

}
