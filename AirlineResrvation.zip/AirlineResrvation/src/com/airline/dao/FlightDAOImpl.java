package com.airline.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.airline.entities.FlightInformation;

@Repository
public class FlightDAOImpl implements IFlightDAO{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<FlightInformation> viewAllFlights() {
		// TODO Auto-generated method stub
		String qry = "SELECT f FROM FlightInformation f";
		TypedQuery<FlightInformation> query = entityManager.createQuery(qry,
				FlightInformation.class);
		return query.getResultList();
	}

}
