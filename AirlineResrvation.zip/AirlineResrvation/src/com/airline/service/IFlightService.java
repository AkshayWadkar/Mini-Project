package com.airline.service;

import java.util.List;

import com.airline.entities.FlightInformation;

public interface IFlightService {
	
	//public List<FlightInformation> viewAllFlights();
	
	public List<FlightInformation> viewAllFlights();

}
