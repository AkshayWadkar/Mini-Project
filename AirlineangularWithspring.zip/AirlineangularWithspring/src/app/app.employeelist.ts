import {Component,OnInit} from '@angular/core';
import {FlightInformation} from './flightinformation';
import {FlightInformationService} from './flightinformation.service';


@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.flightinformationcomponent.html',
    providers:[FlightInformationService]
})
export class EmployeeList implements  OnInit{
    
    flights:FlightInformation[];
    statusmessage:string;


constructor(private flyservice:FlightInformationService) {}
ngOnInit(): void {
    this.flyservice.viewAllFlights().subscribe((flightData)=>this.flights=flightData,
    (error)=>{
        this.statusmessage="Problem with service check server"
           // console.error(error);
    }    
    );
 
}
/* delete(id:number):void{
    this.empservice.deleteEmployeeId(id).subscribe((employeeData)=>this.employees=employeeData,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
} */
 
}