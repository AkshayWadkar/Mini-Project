export class FlightInformation{
    flightno:number;
    airline:string;
    dep_city:number;
    arr_city:string;
    arr_date:Date;
    dep_date:Date;
    fseats: number;
    fseatsfare: number;


}