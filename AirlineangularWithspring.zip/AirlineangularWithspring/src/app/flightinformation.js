"use strict";
var FlightInformation = (function () {
    function FlightInformation() {
    }
    return FlightInformation;
}());
exports.FlightInformation = FlightInformation;
